/// a -> number
/// b -> number

int b = 20;
int main() {
    // int a[(int)4.5*(3&4)-5+6+100] = {0};
    int a[12^9] = {0};
    a[2] = 3*4;
    return a[2];
}