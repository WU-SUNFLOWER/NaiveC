int main() {
    int a = 10;
    while (a < 100) {
        break;
        if ( a == 35 ) 
            break;
        a += 3;
    }

    return 0;
}