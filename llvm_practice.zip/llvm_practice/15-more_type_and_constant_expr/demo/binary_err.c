int main() {
    int a[4] = {0};
    int *p = a + 3;
    return 0;
}