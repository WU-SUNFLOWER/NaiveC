int main() {
    int a = 10;
    int b = 1;
    switch (a)
    {
    case sizeof(2*5): 
        return a + b;
    case b:
        return a * b;
    default:
        break;
    }
    return a;
}