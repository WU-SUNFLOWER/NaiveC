struct A {
    // int a;
    struct A *a;
} a = {0};

int main() {
    return 0;
}