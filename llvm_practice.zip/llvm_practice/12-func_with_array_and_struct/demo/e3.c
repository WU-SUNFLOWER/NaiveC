int a = 10;
int main() {
    if (a != 10) {
        a = 2;
    }
    else {
        a = 20;
    }
    return a;
}