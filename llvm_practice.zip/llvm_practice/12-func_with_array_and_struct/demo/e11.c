int a[] = {1,2,3,4,5};

int main() {
    return sizeof(a);
}