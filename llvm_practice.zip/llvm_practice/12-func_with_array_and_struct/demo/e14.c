struct A {
    int a;
    struct A *p;
};

int main() {
    return 0;
}
