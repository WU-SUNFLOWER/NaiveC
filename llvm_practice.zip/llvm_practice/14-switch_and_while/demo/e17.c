int main() {
    int a = 10;
    do {
        // break;
        if ( a == 43 ) 
            break;
        a += 3;
    }while (a < 100);

    return a;
}