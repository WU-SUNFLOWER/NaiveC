int printf(const char *fmg, ...);

const char *hello = "hello,world\n";

int main() {
    printf("%s\n", hello);
    return 0;
}