int printf(const char *fmg, ...);

const char *hello = "hello,world\n";

int main() {
    char a[] = "hhh";
    char b[] = {"hhh"};
    printf("%s\n", hello);
    return 0;
}